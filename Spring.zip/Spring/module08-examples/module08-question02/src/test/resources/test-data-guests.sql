insert into guests(id, first_name, last_name) values(1, 'Earl', 'Wilkerson');
insert into guests(id, first_name, last_name) values(2, 'Atif', 'Melton');
insert into guests(id, first_name, last_name) values(3, 'Salma', 'Sheridan');