insert into article(id, title, body) values(1, 'First Article', 'This is a content for first article.');
insert into article(id, title, body) values(2, 'Second Article', 'Content for second article.');
insert into article(id, title, body) values(3, 'Third Article', 'Some content for third article.');
insert into article(id, title, body) values(4, 'Lorem ipsum', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.');
insert into article(id, title, body) values(5, 'Donec luctus', 'Donec luctus ligula et nisl ultricies rutrum.');
