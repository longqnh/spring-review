insert into customer(id, code, first_name, last_name, address) values(1, 'CC', 'Caitlin', 'Chen', '190 Buttonwood Dr. Olympia, WA 98512');
insert into customer(id, code, first_name, last_name, address) values(2, 'KT', 'Kamila', 'Terry', '73 South John Street Redondo Beach, CA 90278');
insert into customer(id, code, first_name, last_name, address) values(3, 'EH', 'Eve', 'Harrell', '525 Main St. Austin, MN 55912');
insert into customer(id, code, first_name, last_name, address) values(4, 'AH', 'Adalyn', 'Hooper', '82 Ashley Drive Coraopolis, PA 15108');
insert into customer(id, code, first_name, last_name, address) values(5, 'CF', 'Chase', 'Freeman', '9357 South Newbridge Road Glenside, PA 19038');
insert into customer(id, code, first_name, last_name, address) values(6, 'QA', 'TEST', 'TEST', 'TEST');
