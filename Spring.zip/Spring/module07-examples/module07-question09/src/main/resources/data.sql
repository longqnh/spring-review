insert into article(id, title, body) values(1, 'First Article', 'Content for first article.');
insert into article(id, title, body) values(2, 'Second Article', 'Some content for second article.');
insert into article(id, title, body) values(3, 'Third Article', 'Some content for third article.');
insert into article(id, title, body) values(4, 'Fourth Article', 'Fourth article content.');
