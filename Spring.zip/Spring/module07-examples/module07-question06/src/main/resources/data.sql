insert into customer(id, code, first_name, last_name) values(1, 'CC', 'Caitlin', 'Chen');
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code, customer_id) values(1, 'Home Address', 3992, 'Buffalo Creek Road', 12, 'Nashville', 'TN', '37209', 1);
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code, customer_id) values(2, 'Business Address', 2337, 'Bastin Drive', 14, 'Northampton', 'PA', '18067', 1);

insert into customer(id, code, first_name, last_name) values(2, 'KT', 'Kamila', 'Terry');
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code, customer_id) values(3, 'Home Address', 4363, 'Valley Drive', 8, 'Philadelphia', 'PA', '19108', 2);
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code, customer_id) values(4, 'Business Address', 3224, 'Seneca Drive', 16, 'Portland', 'OR', '97217', 2);

insert into customer(id, code, first_name, last_name) values(3, 'EH', 'Eve', 'Harrell');
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code, customer_id) values(5, 'Home Address', 1755, 'Cemetery Street', 15, 'Salinas', 'CA', '93901', 3);
insert into address(id, address_name, street_number, street_name, apt_number, city, state, zip_code, customer_id) values(6, 'Business Address', 1758, 'Ritter Avenue', 5, 'Roseville', 'MI', '48066', 3);
